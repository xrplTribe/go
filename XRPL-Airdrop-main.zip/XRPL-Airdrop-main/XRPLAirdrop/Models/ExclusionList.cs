﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XRPLAirdrop.Models
{
    public class ExclusionList
    {
        public string account { get; set; }
        public string type { get; set; }
    }
}
